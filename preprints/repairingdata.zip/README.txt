This is the replication package that provides supplementary material.


++++++
Please note that this file may reveal the authors’ identity! Hence, the content is moved to the very bottom of the file to avoid accidental display of the identities.
++++++


































































































































































This is the replication package that provides supplementary material. In the following, we describe each file that is contained in the package.
The executables of the tool may reveal the authors identity! Hence, they are not included in this package. However, they will be published on the
authors’ websites if the paper gets accepted.

Build Change Taxonomy Detail.pdf and Build Change Taxonomy Overview.pdf
==============================
These files contain the taxonomy of Build Changes defined by Macho et al. in their work about extracting Build Changes [1] and the mapping to our categorization.

DataRQ1.pdf
==========
Contains the detailed data for RQ1 mentioned in the paper.

DataRQ2.pdf
==========
Contains the detailed data for RQ2 mentioned in the paper.

MLA Evaluation.pdf
===============
Shows the results of the evaluation of MavenLogAnalyzer as stated in the paper.

MLA Regular Expressions.pdf
=======================
Lists the regular expressions that we use to classify the build logs and the corresponding mappings to the build results.

README
=======
This file.

[1] C.Macho, S.McIntosh, and M.Pinzger,“Extracting Build Changes with BuildDiff,” in Proc. of the International Conference on Mining Software Repositories (MSR), 2017, p. 368-378.  
